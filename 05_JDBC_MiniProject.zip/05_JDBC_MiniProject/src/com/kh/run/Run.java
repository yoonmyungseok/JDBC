package com.kh.run;

import com.kh.view.ProductView;

public class Run {

	public static void main(String[] args) {
		new ProductView().mainMenu();
	}

}
